# Readme

1. Drop the CAM-data txt file into this folder
2. Make sure that split data is empty unless you want it to be otherwise
3. Run CAMEL-Image_Creator\index.html via a live server
4. Run CitizenScience.ipynb1
5. Once the operation is finished, the output files can be found in SVGs