// language file
$(function () {
    document.getElementById("alert-text").innerHTML = languageFileOut.ls_01; // leaving fullscreen
    
    document.getElementById("alert-button-text").innerText =   languageFileOut.continueButtonFullscreen; // fullscreen continue button
});